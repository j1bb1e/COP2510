#Julia Brand
#U28358787
#Due 1/25/24
#Calculates the area of an octagon

s = float(input("Please enter the side length of the octagon: "))
x = 1 + (2 ** 0.5) #middle part, just to simplify final expression
a = 2 * x * (s ** 2)

print("The area of the octagon is: ", "%.5f" % a)