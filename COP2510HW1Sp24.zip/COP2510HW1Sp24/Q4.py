#Julia Brand
#U28358787
#Due 1/25/24
#Finds area of flower given radius of the flower

import math

r = float(input("Enter the radius of the flower: "))
asq = r ** 2 #area of square
ac = math.pi * ((r / 2) ** 2) #area of circle
af = asq + 2 * ac #area of flower

print("The area of the flower is: ", "%.4f" % af)
