#Julia Brand
#U28358787
#Due 1/25/24
#Calculates and displays the slope of the line that connects two points

x1 = float(input("Enter the x-coordinate for point1: "))
y1 = float(input("Enter the y-coordinate for point1: "))
x2 = float(input("Enter the x-coordinate for point2: "))
y2 = float(input("Enter the y-coordinate for point2: "))

num = y2 - y1 #numerator
den = x2 - x1 #denominator
slope = num / den #slope

print(f"The slope for the line that connects the two points ({x1},{y1}) and ({x2},{y2}) is {slope:.3}")
