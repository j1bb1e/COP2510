#Julia Brand
#U28358787
#Due 1/25/24
#Calculates the energy needed to heat water from an initial temperature to a final temperature

m = float(input("Enter the amount of water (in kg): "))
temp1 = float(input("Enter the initial temperature: "))
temp2 = float(input("Enter the final temperature: "))
tempdiff = temp2 - temp1 #difference in temperature
q = m * tempdiff * 4184

print("The energy needed is", f"{q:,}", "joules.")