#Julia Brand
#U28358787
#Due 2/14/24
#Prints the vowels in the string and remaining characters

response = "yes"

while(response == "yes"):
    print("Enter a string of characters: ")
    str = input()

    counta = 0
    counte = 0
    counti = 0
    counto = 0
    countu = 0
    vtotal = 0

    for s in str:
        if(s.lower() == 'a'):
            counta += 1
            vtotal += 1
        elif(s.lower() == 'e'):
            counte += 1
            vtotal += 1
        elif(s.lower() == 'i'):
            counti += 1
            vtotal += 1
        elif(s.lower() == 'o'):
            counto += 1
            vtotal += 1
        elif(s.lower() == 'u'):
            countu += 1
            vtotal += 1


    print("Number of each vowel in the string: ")
    print(f"a: {counta}")
    print(f"e: {counte}")
    print(f"i: {counti}")
    print(f"o: {counto}")
    print(f"u: {countu}")
    print(f"Number of non-vowel characters: {len(str) - vtotal}")
    print("Would you like to enter another string?")
    response = input("Enter yes or no: ")