#Julia Brand
#U28358787
#Due 2/14/24
#Prints the verses of the traveling song “One Hundred Bottles of Beer.” however many times the user wants

num = int(input("How many verses (1 to 100)? "))

while(num < 1 or num > 100):
    num = int(input("How many verses (1 to 100)? "))

count = 100
print()

while(count > 100 - num):
    print(f"{count} bottles of beer on the wall")
    print(f"{count} bottles of beer")
    print("If one of those bottles should happen to fall")
    print(f"{count - 1} bottles of beer on the wall")
    print()
    count -= 1







    