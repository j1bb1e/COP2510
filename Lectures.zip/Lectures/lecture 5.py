#Julia Brand
#U28358787
#Tuesday 1/30/24
#Lecture 5

#intro to dictionaries (mapping type)
#use key value pair

cutenames = {'cat':'floof', 'snake':'danger noodle'}

#use the key to access the value
print(f"A cute name for a {list(cutenames.keys())[0]} is {cutenames['cat']}.")

#print full dictionary
print(cutenames)

#add key/value pair
cutenames['dog'] = 'pupper'
print(cutenames)

#change key/value pair
cutenames['dog'] = 'doggo'
print(cutenames)

#delete entry
del cutenames['dog']
print(cutenames)

#dictionaries can include other containers
scores = {'Annie':[89, 92, 97], 'Brad':[88, 91, 98]}
print(scores['Annie'])

#add another pair of [] to get specific values
print(scores['Annie'][1])

#to key the keys from a dictionary, use the keys() method
print(scores.keys())
#prints name at index 0, have to convert scores.keys() to a list

#add another score value to the list
scores['Annie'].append(87)
print(scores)

#you can concert containers using built in functions
#list() <-- convert another container to a list, use [] to create an empty list
#tuple() <-- convert another container to a tuple
#set() <-- convert another container to a set or create an empty set
#dict() <-- create an empty dictionary or initialize a new dictionary

#membership operators
#in, not in <-- used for containers
char = input("Enter a letter, number, or symbol: ")
name = "Julia"

if(char in name):
    print(f"The character '{char}' is in {name}")
else:
    print(f"The character '{char}' is not in {name}")

#identity operators
#is, is not <-- used to check if two variables refer to the same object

w = 500
x = 1000
y = w + w #y = 1000
z = x #z = 1000

if(z is x):
    print("z and x are bound to the same object")
    print(f"The value of x = {x} and the value of z = {z}")
if(z is not y):
    print("z and y are NOT bound to the same object")


#comparison operators
# <, <=, >, >=, ==, !=

#logical operators
#not (!), and (&), or (|)

temp, rain = input("Enter temperature: "), input("Is it raining? (yes/no): ")
temp = float(temp)

if (rain == 'yes'):
    raining = True
else:
    raining = False

if(temp > 70 and not raining):
    print('Go hiking')
else:
    print("Stay inside")