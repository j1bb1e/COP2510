#Julia Brand
#U28358787
#Tuesday 2/6/24
#Lecture 6

#one way and two way selection
score = int(input("Enter a score(0-100): "))

while(score < 0 or score > 100):
    score = int(input("Invalid. Enter a score(0-100): "))

if(score >= 80):
    print("Yay!")
    print("You advance!")
else:
    print("Oh no!")
    print("Try again")

#rewrite if else using conditional (ternary) statement
#print(true outcome if condition else false outcome)
print("Yay! You advance!" if score >= 80 else "Oh no! Try again!")

#rewrite using walrus operator and ternary form (excluding input validation)
#print("Yay! You advance!" if (score := int(input("Enter a score: ")) >= 80) else "Oh no! Try again!")

#multiple selection
#standard nested if else

if(score >= 90):
    grade = 'A'
else:
    if(score >= 80):
        grade = 'B'
    else:
        if(score >= 65):
            grade = 'C'
        else:
            if(score >= 50):
                grade = 'D'
            else: #trailing else
                grade = 'F'
print(f'The grade is {grade}')

#if-elif-else structure

if(score >= 90):
    grade = 'A'
elif(score >= 80):
    grade = 'B'
elif(score >= 65):
    grade = 'C'
elif(score >= 50):
    grade = 'D'
else: #trailing else
    grade = 'F'
print(f'The grade is {grade}') 

#alternate way to express ranges using only relational operators
#works well with floating point numbers

if(90 <= score <= 100):
    grade = 'A'
if(80 <= score < 90):
    grade = 'B'
if(65 <= score < 80):
    grade = 'C'
if(50 <= score < 65):
    grade = 'D'
if(0 <= score < 50): 
    grade = 'F'
print(f'The grade is {grade}') 

#alternate way to express ranges using in keyword and range function
#range function works with integers

if(score in range(90, 101)):
    grade = 'A'
if(score in range(80, 90)):
    grade = 'B'
if(score in range(65, 80)):
    grade = 'C'
if(score in range(50, 65)):
    grade = 'D'
if(score in range(0, 50)):
    grade = 'F'
print(f'The grade is {grade}') 

#match case can be used for multiple selection 
#assume that C is 70-79 and D is 60-69, F is below 60
#does not work well with floating point numbers
match score // 10:
    case 10 | 9: # | represents or for ranges
        print("Grade is A")
    case 8:
        print('Grade is B')
    case 7:
        print('Grade is C')
    case 6:
        print('Grade is D')
    case _: #default (wildcard) case (same as a trailing else)
        print("Grade is F")

#another match case example
status = int(input("Enter status code: "))
match status:
    case 400:
        msg = "Bad request"
    case 404:
        msg = "Not found"
    case _:
        msg = "Something is wrong"