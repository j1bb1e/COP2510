#Julia Brand
#U28358787
#Thursday 2/29/24
#Lecture 12

#arbitrary keyword arguments

def print_sandwich(meat, bread, **kwargs):
    print(f"{meat} on {bread}")
    for category, extra in kwargs.items():
        print(f"{category}: {extra}")
    print()

print_sandwich("turkey", "sourdough", sauce = "mayo")
print_sandwich("ham", "wheat", sauce1 = "mustard", veggie1 = "tomato", veggie2 = "lettuce")

#string slicing

name = "Julia Brand"
subname = name[3 : 8] #ending position is exclusive
print(subname)

#you can use negative indices
subname2 = name[-5: -2]
print(subname2)

#you can omit starting and ending positions
subname3 = name[4: ] #4 inclusive to end
print(subname3)

subname4 = name[ : -3] #beginning to -3 exclusive
print(subname4)

#see zybook 7.3 for addition string methods

#list comprehension - create a new list by accessing an original list
list1 = [1, 2, 3, 4, 5] #original list
list2 = [i * 10 for i in list1] #expression, for (range variable) in (original list name)
print(list1)
print(list2)

#you can use list comprehension with the ternary form
list3 = [m / 2 if m > 3 else m * 2 for m in list1] #ternary form comes first, then loop
print(list3)

#you can use list comprehension with just an if statement
list4 = [n - 1 for n in list1 if n <= 2] #if statement appears last
print(list4)

#you can use list comprehension with input
#list5 = [(float(input("value? "))) for p in list1]
#print(list5)

#dictionary comprehension
d1 = {q : q**2 for q in range(10)}
print(d1)
print(d1[7])

#dictionary comprehension with multiple if statements
d2 = {k : v for (k, v) in d1.items() if v > 4 if v % 2 == 0} #second if functions as an "and"
print(d2)