#Julia Brand
#U28358787
#Tuesday 3/5/24
#Lecture 13

#file input/output

#ex 1, how to read a txt file
#could leave out the 'r' by default
breedfile = open('C:\COP2510\Lectures\popularbreeds.txt', 'r') #read mode, view content but cannot change it
breeds = breedfile.readlines() #readlines() read contents of file and return a list
breedfile.close()

print(breeds)

#ex 2
with open('C:\COP2510\Lectures\popularbreeds.txt', 'r') as breedfile:
    #breeds = breedfile.readlines()
    #breedfile.close()
    #breedstr = breedfile.read() #read - read contents of file and return a string
    db = breedfile.readline() #read contents of file and return one line at a time, loop is needed
print(db) #prints first line

#clean up list
cats = []
for b in breeds:
    c = b.rstrip() #removes whitespace after text
    cats.append(c)
print(cats)

#example - how to write to a file
# w - write mode; a - append, r+ and w+ represents updates
with open('C:\COP2510\Lectures\sentence.txt', 'w') as outfile:
    outfile.write('Confirm plans for Spring Break.')

with open('C:\COP2510\Lectures\sentence.txt', 'a') as outfile:
    outfile.write("Also get groceries")

#intro to matplotlib plotting
import matplotlib.pyplot as plt

#plotting using a small list
x = [10, 20, 30, 40]
y = [15, 35, 75, 95]

plt.plot(x, y)
plt.show()

#plot imported data
with open('C:\COP2510\Lectures\gltmarch.csv', encoding = 'utf-8-sig') as pfile:
    gtemp = []
    for g in pfile:
        gtemp.append(float(g))

years = range(1900, 2016)
plt.plot(years, gtemp, 'g') #green
plt.xlabel("Year")
plt.ylabel("Global Temperature (F)")
plt.title("March Global Temperatures")
plt.grid(True)
plt.show()