#Julia Brand
#U28358787
#Tuesday 2/23/24
#Lecture 8

import random

for i in range(3):
    print(random.randint(1, 6)) #integers: both endpoints are inclusive
    print(random.randrange(1, 7)) #integers: upper limit is exclusive
    print(random.random()) #floating point in the range 0 (inclusive) to 1 (exclusive)
    print(random.uniform(2.5, 4.0)) 
    print()

import turtle
turtle.speed(0)
turtle.shape('turtle')
#draw a square
for i in range(4):
    turtle.fd(100)
    turtle.dot(5, 'blue')
    turtle.left(90)

turtle.clearscreen()

#draw pattern
turtle.speed(0)
turtle.shape('turtle')

for c in range(36):
    turtle.circle(75)
    turtle.rt(10)

turtle.clearscreen()

#draw a series of circles
turtle.speed(0)
turtle.shape('turtle')

x, y = -300, 0
turtle.penup()
turtle.setpos(x, y)

for c in range(5):
    turtle.pendown()
    turtle.circle(50)
    turtle.penup()
    x += 100
    turtle.setpos(x, y)

turtle.done()

#break and continue with a loop

for i in range (1, 11): #1-10
    if i == 4:
        break #interrupted loop
    print(i, end = ' ')

print()

for i in range (1, 11): #1-10
    if i == 4:
        continue #iskip iteration
    print(i, end = ' ')