#Julia Brand
#U28358787
#Thursday 1/25/24
#Lecture 4

#-----intro to types-----
#strings, lists, tuple, sets, dictionaries

#strings - sequence type (contents have order), use index to access specific value
#last index is -1

name = "Julia Brand" 
print(f"The first value in {name} is {name[0]}")
print(f"The last value in {name} is {name[-1]}")

#strings are immutable
#len function - function used to obtain the size of a list
print(f"The name {name} has {len(name)} characters")

#Lists - containers (structure that can hold different types of data)
#lists are also a sequence - contents are ordered

pets = ["Leo", 4, "Wammy", 3]
print(pets)
print(pets[0])
print(pets[0][1]) #prints second letter of first item
print(f"Leo has {len(pets[0])} letters")

#lists are mutable
pets[0] = "Luna"
print(pets)

#useful methods for lists: append, pop, remove
pets.append("Leo") #add value to end of list
print(pets)

pets.pop() #remove last value by default OR put index in the () to remove at that index
print(pets)

pets.remove("Wammy") #removes first occurance of value
print(pets)

#lists within list

nlist = [1, 2, 3, [4, 5, 6], 7]
print(nlist)
print(nlist[3])
print(nlist[3][1])

#tuple - sequence and container, but immutable
somethings = (1, "A", 5.4) #list but cannot add or remove anything
print(somethings[1])

#sets - conntainer, not a sequence. use for storing unique values

s1 = {1, "two", 3, 4, 5, 1}
print(s1) #duplicates are removed, everything put in order, cannot refer to a position
#methods - add, remove, pop

s1.add(2)
s1.remove(5)
print(s1)
s1.pop() #removes a random element
print(s1)

