#Julia Brand
#U28358787
#Tuesday 4/9/24
#Lecture 17

#protected attribute example: inherit data and methods
class Shape:
    def __init__(self, l, w):
        self._length = l #one _ is that the attribute is protected, available to this and child classes
        self._width = w

    def __str__(self):
        return f"Length: {self._length}, width: {self._width}"
    
class Rectangle(Shape):
    def __init__(self, l, w):
        Shape.__init__(self, l, w)

    def setlength(self, l):
        self._length = l

    def setwidth(self, w):
        self._width = w

    def area(self):
        print(f"The area is {self._length * self._width}")

#end of class definitions

#driver portion below

r = Rectangle(80, 20)
print(r)
r.area()
r.setlength(100)
r.setwidth(10)
print(r)
r.area()
print()

#all about polymorphism (many forms)

#example 1 - polymorphism in built in functions
print(len('2 and a half more weeks')) #return number of characters
print(len([1, 2, 3]))

#example 2 - polymorphism in programmer defined functions
def add(x, y, z = 0):
    return x + y + z

print(add(2, 3))
print(add(2, 3, 4))

#example 3 - polymorphism in classes

class Canada:
    def capital(self):
        print("Canada's capital: Ottowa")

class USA:
    def capital(self):
        print("USA's capitol: Washington DC")

canada = Canada()
usa = USA()

for country in (canada, usa):
    country.capital()

print()

#example 4 - polymorphism in inheritance

class Bird:
    def intro(self):
        print("There are many types of birds.")

    def flight(self):
        print("Some birds can fly, while others cannot.")

class Robin(Bird):
    def flight(self):               #method overriding - when a method from child class is defined
        print("Robins can fly.")    #with the same name as one in the parent class

class Penguin(Bird):
    def flight(self):
        print("Penguins cannot fly.")

bird = Bird()
robin = Robin()
penguin = Penguin()

bird.intro()
bird.flight()

robin.intro()
robin.flight()

penguin.intro()
penguin.flight()

print()

#exceptions - errors that can be REASONABLY handled, not every error is an exception

#try block - code where an exception can occur

try:
    value1 = int(input("Enter a number: "))


#except block - area where exception is handled

except ValueError:
    print("Wrong value entered")