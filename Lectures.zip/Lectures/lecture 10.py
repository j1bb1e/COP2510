#Julia Brand
#U28358787
#Tuesday 2/20/24
#Lecture 10

a = 15 #global variable (defined outside of function or block)
MAX = 100 #global 'constant' - great idea

def main():
    a = 5 #local variable (defined inside of function or block)
    print(f"In main: a is {a}")
    fun1(a)
    fun2(a)
    fun3()
    print(f"In main: a is {a}")

a = 15

def fun1(x):
    print(f"In fun1: x is {x}")
    print(f"In fun1: a is {a}")

def fun2(a):
    a += 7
    print(f"In fun2: a is {a}")
    return #not necessary - can be used to exit a function

def fun3():
    print(f"In fun3: a is {a}")
    print(f"In main: MAX is {MAX}")

def printlist(l): #l is a list parameter
    for (i, e) in enumerate(l):
        print(f"index is {i} and element is {e}")


list1 = [1, 2, 3, 4, "five", 6]
printlist(list1)

#default parameters - have value assigned in its definition
#once a default parameter is created, all subsequence parameters must also be default
def printdate(month, day, year = 2024, style = 1): #user can choose not to input year & style
    if(style == 1):
        print(f"{month} / {day} / {year}")
    elif(style == 2):
        print(f"{day} / {month} / {year}")
    elif(style == 3):
        print(f"{year} / {month} / {day}")
    else:
        print(f"Invalid format")

printdate(9, 3, 2005)
printdate(9, 3, 2005, 2)
printdate(2, 20)
printdate(2, 20, style = 2) #changes style without changing year

