from lecture16_1 import App

def main():
    insta = App("Instagram", "Photo/Video sharing")
    print(insta)
    apprdate(insta, "October", "2010")
    print(f"You have referred to {App.numapp} apps so far.")

    fb = App("Facebook", "Social Media")
    print(fb)
    apprdate(fb, "February", "2004")
    print(f"You have referred to {App.numapp} apps so far.")

def apprdate(aobj, mth, yr):
    print(f"{aobj} that was created in {mth} {yr}")

main()