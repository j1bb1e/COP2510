#Julia Brand
#U28358787
#Thursday 2/8/24
#Lecture 7

#count controlled while loop
i = 1 #initialization
while(i <= 5): #condition
    print(f"i is {i}")
    i += 1 #update

#while loop with walrus operator for input validation

while(num := int(input("Enter a positive number: "))) < 0:
    print("invalid")
print(f"num is {num}")

#for loop (alternate to the counter controlled while loop)
for j in range(5): #starts at 0 ends at 4
    print(f"j is {j}")

print()

for j in range(1, 11): #starts at 1 ends at 10
    print(f"j is {j}")

print()

for j in range(1, 11, 2): #starts at 1 ends at 10, increments by 2
    print(f"j is {j}")

print()

for j in range(20, 1, -2): #starts at 20, ends at 2, decrements by 2
    print(f"j is {j}")

print()

#create a count controlled loop with user input
n = int(input("How many times do you want to repeat? "))

for a in range(n): #0 to n
    print(f"iterating {n} times")

print()

names = ['Julia', 'Leo', 'Wammy', 18, 4]

for b in names:
    print(f"name is {b}")

print()

for b in range(len(names)):
    print(f"name is {names[b]}")

print()

#for loop with string

plan = "Take a nap after class."

for s in plan[0:4]: #refers to the substring "Take" indices 0-3 and 4 is excluded
    print(s, end = ' - ')