#Julia Brand
#U28358787
#Tuesday 1/23/24
#Lecture 3

#-----multiple input--------------------------------------------------------

""" #option 1: use multiple input statements
print("Enter 2 values (click enter after each):")
a = int(input())
b = float(input())
f = a - b
print(f)

#option 2: read all input as strings, then convert as needed
c, d = input("Enter another 2 values (separated by spaces):").split()
#c = int(c)
#d = float(d)
#g = c * d
g = int(c) * float(d)
print(g) """

#walrus operator with input
#print("h is", h := int(input("Enter an integer: ")))
#print(f"h is {(h := int(input("Enter an integer: ")))}")


#-----importing modules---------------------------------------------------------------
#option 1: import entire module, then use dot operator to access the method
import math, random

num = float(input("Enter a positive number: "))
sq = math.sqrt(num)
print(f"The square root of {num} is {sq:.7f}")

r = random.randint(1,6)
print(f"Here is a random int between 1 and 6: {r}")

#option 2: import the specific method(s)
from math import ceil, trunc
ce = ceil(num)
t = trunc(num)
print(f"{num} rounded up is {ce}")
print(f"{num} truncated us {t}")

#option 3: import all methods using wildcard (*)
from math import *
#limit - works with only one module at a time
fnum = fabs(num)
print(f"The absolute value of {num} is {fnum}")

#python does allow you to "rename" modules (within your own file) aka alias
from random import random as rand

r2 = rand()
print(f"Here is another random number: {r2}")

