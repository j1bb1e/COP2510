#Julia Brand
#U28358787
#Thursday 1/11/24
#Lecture 1

'''This (string in triple quotes) can be used
for multi-line comments'''

#output - use print command
print('I am excited for COP 2510 this semester')
# \ - escape sequence
print('I\'m excited for COP 2510 this semester') #\' - print a single quote
print("I'm excited for COP 2510 this semester")
print()
print('She said "hi"')
print("\n")
print('She said \"hi\"')
print()
print('''She said 'hi' and "hi" and
hiiiiiiiiiiiiiiiiii and hellooo''')
print()
print(2, end = '...') #replaces the default \n with ...
print(1)

#effect of sep parameter
print(3, 2, 1, sep = '...')
print()
