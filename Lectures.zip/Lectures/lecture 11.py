#Julia Brand
#U28358787
#Tuesday 2/27/24
#Lecture 11

#standard function
def add5(n):
    return n + 5

#Lambda function - small anonymous functions
number = int(input("Enter a number: "))
val = lambda n1: n1 + 5

#Test standard function
print(f"Standard function: {number} + 5 = {add5(number)}")

#Test lambda function
print(f"Lambda function: {number} + 5 = {val(number)}")

#Lambda functions can be used with ternary statement and default parameters
minval = lambda c = 1, d = 2: c if c <= d else d

n3, n4 = input("Enter two more numbers (separate by a space): ").split()
n3, n4 = float(n3), float(n4)
print(f"The smaller value is {minval(n3, n4)}")
print(f"The smaller value is {minval(n3)}")
print(f"The smaller value is {minval()}")
