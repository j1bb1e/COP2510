#Julia Brand
#U28358787
#Thursday 2/15/24
#Lecture 9

#loop else
for i in range(1, 11):
    if i == 7:
        continue
    print(i, end = ' ')
else: #run if the loop completes all or most of its iterations
    print("The loop has ended")

#nested loops
i = 0
while(i <= 9): #outer loop
    j = 0
    #break #no output
    while(j <= 9): #inner loop
        print(f"{i}-{j}")
        j += 1
        #break #inner loop interrupted but not outer loop
    i += 1
    break #outer loop runs once, inner loop completes its iterations

#enumerate function
for i, j in enumerate(range(1, 11)):
    print(f"{i} ... {j}")

print()

values = [4, 7, 9, 12, 16]
for i, j in enumerate(values):
    print(f"{i} + {j} = {i + j}") #i is position, j is value

#intro to user created functions
def addval(a, b):
    return a + b

print(f"1 + 4 = {addval(1, 4)}")

def main():
    x = int(input("Enter a value: "))
    print(f"In main: value of x is {x}")
    print(tripval(x))

def tripval(x):
    print(f"In tripval: value of x is {x}")
    x *= 3
    return x

main()