#Julia Brand
#U28358787
#Thursday 1/18/24
#Lecture 2

# variables and f strings

#identifier - name of any component in program
#rules: letters, digits, underscore allowed; cannot start w a digit
#also avoid keywords and predefined words

#variable - named space in memory (whose value can change)
#order is important; variable is on LHS, value or expression on RHS
#LHS - left hand side
#RHS - right hand side  
var = 10 #assignment operator

#echo printing - verify values stores in variables
print("var is", var)

#--------------------------------------------------------------------------------------

rate = 0.6542567
print(f'Your new rate is {rate:.3%}') #format as a %, .3% takes value * 100 to 3 decimal places
print(f'Your new rate is {rate:%}') #.format as a % with no limitation

#operator precedence
# ()
# ** exponent (2**3 = 8)
# * / // % left to right
# + -

print(2 ** 3 + 4)

x = 10 #initialization, declaration
x = x + 9 #update statement
#x *= y + 2 is equivalent to x = x * (y + 2)

#7 % 5 = 2
#-7 % 5 = 3
#7 % -5 = -3

print("Type a number")
var2 = input() #no readable prompt, var2 is a string
print("Your number is", var2)
print("Type a new number")
var2 = int(input()) #var2 is an integer

name = input("Enter your name:")
print("Hello", name)