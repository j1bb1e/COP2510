#Julia Brand
#U28358787
#Tuesday 3/19/24
#Lecture 14

#intro to classes
#object - entity that has both state (attributes) and behavior (functions)

#how to not create a class
class Test:
    pass #placeholder for meaningful code

#better way to create a class
class Television:
    #create an initializer method (helps to set up an object)
    def __init__(self): #runs automatically when an object is created
        self.__channel = 1 #self is a placeholder for the object
        self.__volume = 1 #attributes: channel, volume, power
        self.__power = False #on is true, off is false

    #or instead of self you can put parameters and set it = to parameters but self is first parameter

    #accessor (getter) methods - get a value from an attribute
    def getchannel(self):
        return self.__channel
    
    def getvolume(self):
        return self.__volume
    
    def getpower(self):
        if self.__power:
            status = "On"
        else:
            status = "Off"  
        return status

    #mutator (setter) methods - change values in attribute
    def setchannel(self, ch):
        self.__channel = ch

    def setvolume(self, vol):
        self.__volume = vol

    def setpower(self, pow):
        self.__power = pow

    def __str__(self):
        return f"TV stats:\nChannel: {self.__channel}\nVolume: {self.__volume}\nPower: {self.__power}"

#---- end class definition----

def main():
    test1 = Test() #not a great object
    print(test1)
    test1.name = "Programming Exam 1" #create an attribute to store data
    print(f"{test1.name} is on Thursday March 21st.")

    #create a television object
    tv1 = Television()

    #test mutator
    tv1.setchannel(60)


    #test accessor
    print(f"The tv is set to channel {tv1.getchannel()} and it is {tv1.getpower()}")
    print(tv1)

main()