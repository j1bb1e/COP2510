#Julia Brand
#U28358787
#Thursday 3/28/24
#Lecture 15

#four pillars of OOP
#abstraction - allows us to hide unnecessary details from the user
#encapsulation - allows objects to govern themselves
#inheritence - allows us to reuse software
#polymorphism - many forms, components in python can take several forms

class Person:
    def __init__(self, name):
        self.__name = name

    def displayName(self):
        print(self.__name)

per1 = Person("Julia")
per1.displayName()

#print(per1.__name) - attribute error because attribute is hidden, violating encapsulation

#---create a list of objects---
#1. start w class definition
class App:
    def __init__(self, name, apptype):
        self.appname = name
        self.apptype = apptype

    def __str__(self):
        return self.appname.ljust(20) + self.apptype.rjust(20)
#---end class---
    
#2. create a function that produces a list of objects
def applist(n):
    alist = []

    for i in range(n):
        name = input("App name: ")
        apptype = input("App category: ")

        #create an app object
        obj = App(name, apptype) 
                                    #or alist.append(App(name, apptype))
        #add object to the list
        alist.append(obj)

    return alist

#3. create a function to display list of apps
def displayapps(alist):
    for i in alist:
        print(i)

#4. test your class and functions in main
def main():
    num = int(input("Enter a number of apps: "))

    apps = applist(num) #apps will become a list of objects

    #echoprint list of objects
    displayapps(apps)

main()