#intro to inheritance

#---class definitions begin here---
#parent class, (super, base) class

class Vehicle:
    def __init__(self, make, model, year):
        self.__make = make
        self.__model = model
        self.__year = year

    def getmake(self):
        return self.__make
    
    def getmodel(self):
        return self.__model
    
    def getyear(self):
        return self.__year

#child class, (sub, derived) class

class Car (Vehicle): #inheritance established
    def __init__(self, make, model, year, doors):
        Vehicle.__init__(self, make, model, year) #explicitely called the parent class' init method
        self.__doors = doors #set up additional attributes that are specific to Car object

    def getdoors(self):
        return self.__doors
    
#child class of child class (grandchild class of original)

class ElectricCar(Car):
    def __init__(self, make, model, year, doors, bvolt):
        Car.__init__(self, make, model, year, doors)
        self.__bvolt = bvolt

    def getbvolt(self):
        return self.__bvolt

#---class definitions end here---

#---driver begins here---

#create Vehicle object
v1 = Vehicle("Hyundai", "Accent", 2012)
print(f"I drive a {v1.getyear()} {v1.getmake()} {v1.getmodel()}")

#create Car object
c1 = Car("Honda", "Civic", 2009, 4)
print(f"You drive a {c1.getyear()} {c1.getmake()} {c1.getmodel()} with {c1.getdoors()} doors")

#create an ElectricCar object
e1 = ElectricCar("Chevy", "Volt", 2025, 4, 75)
print(f"We drive a {e1.getyear()} {e1.getmake()} {e1.getmodel()} with \
{e1.getdoors()} doors and {e1.getbvolt()} voltage")
print()
print()
#---driver ends here---


#Multiple Inheritance
class Animal:
    def __init__(self, name):
        print(f"{name} is an animal")
        super().__init__(name) #does next in Cat order, which is CannotFly


class CannotFly:
    def __init__(self, name):
        print(f"{name} cannot fly")
        super().__init__(name) #does next in Cat order, which is LikesToHunt


class LikesToHunt:
    def __init__(self, name):
        print(f"{name} likes to hunt")


class Cat(Animal, CannotFly, LikesToHunt): #multiple inheritance
    def __init__(self, name):
        print(f"I'm a cat named {name}")
        super().__init__(name)

#---driver begins here---
c = Cat("Leo")