#Julia Brand
#U28358787
#Due 4/3/24
#Makes polygon class to convey information about a polygon that user gave side length and num of sides

import math

class Polygon:
    def __init__(self):
        self.__sides = 0
        self.__length = 0.0

    def setSides(self, n):
        self.__sides = n

    def setLength(self, s):
        self.__length = s

    def getSides(self):
        return self.__sides

    def getLength(self):
        return self.__length
    
    def perimeter(self):
        return self.__sides * self.__length
    
    def area(self):
        numerator = self.__sides * (self.__length**2)
        denominator = 4 * math.tan(math.pi / self.__sides)
        return numerator / denominator
    

def main():
    p = Polygon()

    n = int(input("Enter the number of sides (>=3): "))
    while n < 3:
        n = int(input("Invalid entry. Re-enter the number of sides (>=3): "))
    
    s = float(input("Enter the length of each sides (>= 0.1): "))
    while s < 0.1:
        s = float(input("Invalid entry. Re-enter the length of each sides (>= 0.1): "))
    
    p.setSides(n)
    p.setLength(s)

    print(f"The polygon has {p.getSides()} sides. Each side is {p.getLength()} units in length.")
    print(f"The perimeter of the polygon is {p.perimeter():.3f} units and its area is {p.area():.3f} square units.")

main()