#Julia Brand
#U28358787
#Due 4/3/24
#Adds items to cart and displays item, amount, and cost using retail class

class RetailItem:
    def __init__(self, item, qty, price):
        self.__item = item
        self.__qty = qty
        self.__price = price
    
    def __str__(self):
        return f'{self.__item:16}{self.__qty:16}${self.__price:16}'


def itemList(n):
    ilist = []

    for i in range(n):
        name = input(f"Name of item {i + 1} ")
        amt = input(f"Amount of item {i + 1}: ")
        cost = input(f"Price of item {i + 1}: ")

        obj = RetailItem(name, amt, cost) 

        ilist.append(obj)
    print(ilist)
    return ilist

def main():
    num = int(input("How many items will you add today? (>= 1): "))
    while num < 1:
        num = int(input("Invalid entry. How many items will you add today? (>= 1): "))

    items = itemList(num)

    print("Here is a summary of the 3 items you added:")
    print(f'{"Item":16}{"Amount":16}{"Price":16}')
    print(f"{"-" * 37}")

    for i in items:
        print(i)
    

main()