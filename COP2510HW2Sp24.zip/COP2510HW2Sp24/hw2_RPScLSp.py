#Julia Brand
#U28358787
#Due 2/6/24
#Simulates game of Rock Paper Scissors Lizard Spock

import random

moves = ["rock", "paper", "scissors", "lizard", "spock"]

print("Let's play Rock, Paper, Scissors, Lizard, Spock!")
pc = input("Enter your choice: ").lower() #player choice
cc = random.choice(moves) #computer choice
print(f"Computer chose {cc}")

if(pc == cc):
    print("It's a tie!")
elif(pc == "rock"):
    if(cc == "paper"):
        print("Paper covers rock! Computer wins!")
    elif(cc == "scissors"):
        print("Rock crushes scissors! You win!")
    elif(cc == "lizard"):
        print("Rock crushes lizard! You win!")
    elif(cc == "spock"):
        print("Spock vaporizes rock! Computer wins!")
elif(pc == "paper"):
    if(cc == "rock"):
        print("Paper covers rock! You win!")
    elif(cc == "scissors"):
        print("Scissors cuts paper! Computer wins!")
    elif(cc == "lizard"):
        print("Lizard eats paper! Computer wins!")
    elif(cc == "spock"):
        print("Paper disproves spock! You win!")
elif(pc == "scissors"):
    if(cc == "rock"):
        print("Rock crushes scissors! Computer wins!")
    elif(cc == "paper"):
        print("Scissors cuts paper! You win!")
    elif(cc == "lizard"):
        print("Scissors decapitates lizard! You win!")
    elif(cc == "spock"):
        print("Spock smashes scissors! Computer wins!")
elif(pc == "lizard"):
    if(cc == "rock"):
        print("Rock crushes lizard! Computer wins!")
    elif(cc == "paper"):
        print("Lizard eats paper! You win!")
    elif(cc == "scissors"):
        print("Scissors decapitates lizard! Computer wins!")
    elif(cc == "spock"):
        print("Lizard poisons spock! You win!")
elif(pc == "spock"):
    if(cc == "rock"):
        print("Spock vaporizes rock! You win!")
    elif(cc == "paper"):
        print("Paper disproves spock! Computer wins!")
    elif(cc == "scissors"):
        print("Spock smashes scissors! You win!")
    elif(cc == "lizard"):
        print("Lizard poisons spock! Computer wins!")

print("Thanks for playing!")