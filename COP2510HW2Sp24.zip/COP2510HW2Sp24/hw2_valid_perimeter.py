#Julia Brand
#U28358787
#Due 2/6/24
#Determines whether sides of a triangle are valid and prints perimeter if it is valid

a = float(input("Enter length of edge1: "))
b = float(input("Enter length of edge2: "))
c = float(input("Enter length of edge3: "))

if(a + b < c) | (b + c < a) | (a + c < b):
    print("Perimeter cannot be calculated: the input is invalid.")
else:
     perimeter = a + b + c
     print(f"The perimeter is {perimeter}")