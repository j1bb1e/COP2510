#Julia Brand
#U28358787
#Due 4/15/24
#Class that represents a question in a trivia game

class QuestionClass:
    def __init__(self, q, a1, a2, a3, a4, ca):
        self.__q = q
        self.__a1 = a1
        self.__a2 = a2
        self.__a3 = a3
        self.__a4 = a4
        self.__ca = ca
    
    def getAns(self):
        return self.__ca
    
    def __str__(self):
        return f"{self.__q}\n1. {self.__a1}\n2. {self.__a2}\n3. {self.__a3}\n4. {self.__a4}"