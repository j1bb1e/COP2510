#Julia Brand
#U28358787
#Due 4/15/24
#Creates a list of trivia question objects

from Question import QuestionClass

def qList():
    qlist = []

    q = "How many days are in a lunar year?"
    a1 = "354"
    a2 = "365"
    a3 = "243"
    a4 = "379"
    ca = 1

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    q = "What is the largest planet?"
    a1 = "Mars"
    a2 = "Jupier"
    a3 = "Earth"
    a4 = "Pluto"
    ca = 2

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    q = "What is the largest kind of whale?"
    a1 = "Orca"
    a2 = "Humpback"
    a3 = "Beluga"
    a4 = "Blue"
    ca = 4

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    q = "Which dinosaur could fly?"
    a1 = "Triceratops"
    a2 = "T-rex"
    a3 = "Pteranodon"
    a4 = "Diplodocus"
    ca = 3

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    q = "Which of these Winnie the Pooh characters is a donkey?"
    a1 = "Pooh"
    a2 = "Eeyore"
    a3 = "Piglet"
    a4 = "Kanga"
    ca = 2

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    q = "What is the hottest planet?"
    a1 = "Mars"
    a2 = "Pluto"
    a3 = "Earth"
    a4 = "Venus"
    ca = 4

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    q = "Which dinosaur had the largest brain compared to body size?"
    a1 = "Troodon"
    a2 = "Stegosaurus"
    a3 = "Ichthyosaurus"
    a4 = "Gigantoraptor"
    ca = 1

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    q = "What is the largest type of penguins?"
    a1 = "Chinstrap"
    a2 = "Macaroni"
    a3 = "Emperor"
    a4 = "White-flippered"
    ca = 3

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    q = "Which children's story character is a monkey?"
    a1 = "Winnie the Pooh"
    a2 = "Curious George"
    a3 = "Horton"
    a4 = "Goofy"
    ca = 2

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    q = "How long (in earth days) is a year on Mars?"
    a1 = "550"
    a2 = "498"
    a3 = "126"
    a4 = "687"
    ca = 4

    obj = QuestionClass(q, a1, a2, a3, a4, ca)
    qlist.append(obj)

    return qlist