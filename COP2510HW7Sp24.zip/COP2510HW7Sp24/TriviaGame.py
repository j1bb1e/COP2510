#Julia Brand
#U28358787
#Due 4/15/24
#Executes trivia game based on trivia questions

import Question
import TriviaQns

qlist = TriviaQns.qList()

player = "first"
p1 = 0
p2 = 0

for i in qlist:
    print(f"Question for the {player} player: ")
    print(i)
    playerAns = int(input("Enter your solution (a number between 1 and 4): "))

    ca = i.getAns()

    if playerAns == ca:
        print("That is the correct answer.")
        if player == "first":
            p1 += 1
        elif player == "second":
            p2 += 1
    else:
        print(f"That is incorrect. The correct answer is {ca}")

    if player == "first":
        player = "second"
    elif player == "second":
        player = "first"

    print()

print(f"The first player earned {p1} point(s)")
print(f"The second player earned {p2} point(s)")

if p1 > p2:
    print("The first player wins the game.")
elif p1 < p2:
    print("The second player wins the game.")
else:
    print("It is a tie.")