#Julia Brand
#U28358787
#Due 3/6/24
#uses the Babylonian method to compute the square root of a user inputted number

import math

def main():
    print("This program will calculate the square root of a number\nusing the Babylonian method.\n")
    x = float(input("Enter a positive number: "))
    while(x <= 0):
        print("Number must be greater than 0.")
        x = float(input("Re-enter a number: "))
    print(f"The square root of {x} is {sqrt(x)}")


def sqrt(n):
    default = 1
    prevguess = default
    nextguess = (prevguess + n / prevguess) / 2

    while(math.fabs(nextguess - prevguess) >= 0.00001):
        prevguess = nextguess
        nextguess = (prevguess + n / prevguess) / 2

    return nextguess

main()