#Julia Brand
#U28358787
#Due 3/6/24
#calculates and displays the cost of the paint needed to complete the task

import math

def main():
    l = 0
    w = 0
    h = 0

    l = int(input("Enter the room's length (in feet): "))
    while(l <= 0):
        print("The value you entered for the length is invalid.")
        l = int(input("Re-enter the room's length (in feet): "))

    w = int(input("Enter the room's width (in feet): "))
    while(w <= 0):
        print("The value you entered for the width is invalid.")
        w = int(input("Re-enter the room's width (in feet): "))

    h = int(input("Enter the room's height (in feet): "))
    while(h <= 0):
        print("The value you entered for the height is invalid.")
        h = int(input("Re-enter the room's height (in feet): "))

    output(l, w, h)

def output(len, wid, ht):
    PPG = 28
    area = (2 * len * ht) + (2 * wid * ht)
    gallons = calcGal(area)
    print(f"You will need {gallons} gallons")
    price = PPG * gallons
    print(f"The price to paint the room is ${price:.2f}")

def calcGal(a):
    FPG = 350
    numgal = math.ceil(a / FPG)
    return numgal

main()