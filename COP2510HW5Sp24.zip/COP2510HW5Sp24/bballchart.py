#Julia Brand
#U28358787
#Due 3/18/24
#create bar chart for members of a basketball team and points that they scored

import matplotlib.pyplot as plt 

names = []
for i in range(5):
    name = input(f"Enter the name of player {i + 1}: ")
    names.append(name)

points = []

for i in range(5):
    print(f"Enter the points earned by {names[i]}: ")
    val = int(input())
    while(val < 0):
        print(f"Invalid points entered. Re-enter the points earned by {names[i]}")
        val = int(input())
    points.append(val)

plt.bar(names, points)
plt.title("Chart showing points scored by each basketball player")
plt.ylabel("Points")
plt.show()