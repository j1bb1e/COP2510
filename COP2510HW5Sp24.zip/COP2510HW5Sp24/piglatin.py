#Julia Brand
#U28358787
#Due 3/18/24
#Converts each word from a file to pig latin and puts in another file

name = input("What is the name of the file? ")

f = open(name)

str = f.read()

l = str.split()

str = ""
word = ""
letter = ""

for i in l:
    if(len(i) == 1):
        word = i + "ay" + " "
        str += word
    else:
        letter = i[0]
        word = i[1:]
        word += letter + "ay" + " "
        str += word

resultfile = input("What is the name of the result file?")

with open(resultfile, 'w') as outfile:
    outfile.write(str)