#Julia Brand
#U28358787
#Thursday 3/21/24
#Randomly selects cards from a single deck and prints in order they were drawn
import random

suits = ["Clubs", "Diamonds", "Hearts", "Spades"]
ranks = ["Ace", 2, 3, 4, 5, 6, 7, 8, 9, 10, "Jack", "Queen", "King"]

def buildDeck(s, r):
    deck = []

    for i in s:
        for j in r:
            deck.append(f"{j} of {i}")  
    return deck

def selectCard(num, deck, cardsDealt = []):
    for i in range(num):
        pick = random.choice(deck)
        cardsDealt.append(pick)
        deck.remove(pick)
    return cardsDealt

def main():
    print("How many cards to draw from deck?")
    x = int(input())
    while(x < 1 or x > 52):
        print("Invalid entry, you can only draw between 1 & 52 cards!")
        print("How many cards to draw from deck?")
        x = int(input())
    
    d = buildDeck(suits, ranks)

    cardList = selectCard(x, d)

    for i, j in enumerate(cardList):
        if i + 1 == 52 or i + 1 == x:
            print(f"And your last card is the {j}") 
        elif i + 1 == 1 or i + 1 == 21 or i + 1 == 31 or i + 1 == 41 or i + 1 == 51:
            print(f"Your {i+1}st card is the {j}")
        elif i + 1 == 2 or i + 1 == 22 or i + 1 == 32 or i + 1 == 42:
            print(f"Your {i+1}nd card is the {j}")
        elif i + 1 == 3 or i + 1 == 23 or i + 1 == 33 or i + 1 == 43:
            print(f"Your {i+1}rd card is the {j}") 
        else:
            print(f"Your {i+1}th card is the {j}") 

main()