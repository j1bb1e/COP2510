#Julia Brand
#U28358787
#Thursday 4/11/24
#desc

#dictionary lecture5
#class definition lecture15
#object creation lecture15+
#inheritance lecture16.3 and lecture17